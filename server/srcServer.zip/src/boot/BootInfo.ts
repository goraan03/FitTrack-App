import { randomUUID } from "crypto";

export const BOOT_ID = randomUUID();
export const BOOT_STARTED_AT = new Date();