export type PendingRatingRow = {
  termId: number;
  startAt: Date;
  durationMin: number;
  title: string;
  userId: number;
  userName: string;
};