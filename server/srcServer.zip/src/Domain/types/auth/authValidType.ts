export type authValidType = {
    uspesno: boolean;
    poruka?: string;
}